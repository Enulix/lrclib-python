# lrclib-python
An extremely basic wrapper for the lrclib api, a lightweight alternative to lrclibapi
